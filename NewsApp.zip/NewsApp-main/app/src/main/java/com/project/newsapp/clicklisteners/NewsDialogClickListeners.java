package com.project.newsapp.clicklisteners;

public interface NewsDialogClickListeners {

    void onGotoWebSiteClick(String url);
    void onDismissClick();

}
